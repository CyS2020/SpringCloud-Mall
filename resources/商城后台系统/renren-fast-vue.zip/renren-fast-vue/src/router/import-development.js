module.exports = file => require('@/views/' + file + '.vue').default
